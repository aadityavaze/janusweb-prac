# VR-Controller-Daydream
3D Model of Google Daydream Controller

This is a 3D model of the Google Daydream Controller. The model is a low poly model and was created from rje's model on Sketchfab - https://sketchfab.com/models/c1944c64e06544babc90e9d0aa953551# under the CC Attribution license.

I have modified it to have separate objects for all the buttons and have re-textured. This was created specifically for the A-Frame project (http://aframe.io) but is free for use as long as you include this README and also attribute rje as requested.

![Rendered Image](https://github.com/TechnoBuddhist/VR-Controller-Daydream/blob/master/vr_controller_daydream_render.png)

Enjoy!



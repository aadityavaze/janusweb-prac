elation.elements.define('janus.ui.chat', class extends elation.elements.base {
  create() {
    this.innerHTML = elation.template.get('janus.ui.chat');
  }
});


elation.elements.define('janus.ui.inventory', class extends elation.elements.base {
  create() {
    this.innerHTML = elation.template.get('janus.ui.inventory');
  }
});

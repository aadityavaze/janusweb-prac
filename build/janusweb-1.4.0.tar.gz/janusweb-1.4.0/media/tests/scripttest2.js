room.update = function() {
  console.log('do shit in room 2', room.objects);
}
